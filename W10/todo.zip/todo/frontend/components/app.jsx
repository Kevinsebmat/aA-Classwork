import React from 'react'
import TodoListIndexContainer from './todo_list_index_container'
const App = () => {
    return (
        <div>
            <h1>TodoList</h1>
            <TodoListIndexContainer/>
        </div>
    )
};


export default App
