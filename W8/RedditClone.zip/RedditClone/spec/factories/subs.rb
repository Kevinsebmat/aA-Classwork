FactoryBot.define do
  factory :sub do
    
  end
end
